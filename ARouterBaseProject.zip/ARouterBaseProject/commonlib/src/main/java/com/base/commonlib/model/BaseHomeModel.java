package com.base.commonlib.model;

public class BaseHomeModel {

    public String add;
    public  int count;

    public BaseHomeModel(String add, int count) {
        this.add = add;
        this.count = count;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
