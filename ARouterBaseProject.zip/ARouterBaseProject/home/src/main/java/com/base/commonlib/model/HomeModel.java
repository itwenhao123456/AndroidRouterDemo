package com.base.commonlib.model;

public class HomeModel extends BaseHomeModel{

    private String add;
    private  int count;

    public HomeModel(String add, int count) {
        super(add, count);
        this.add = add;
        this.count = count;
    }

    public String getAdd() {
        return add;
    }

    public int getCount() {
        return count;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
